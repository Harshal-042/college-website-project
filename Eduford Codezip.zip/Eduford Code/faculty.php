<?php
// Start the session
session_start();

// Initialize variables for error messages
$errorMessage = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $name = trim($_POST['name']);
    $number = trim($_POST['number']);
    $password = trim($_POST['password']);

    // Validate the input
    if (empty($name) || empty($number) || empty($password)) {
        $errorMessage = "All fields are required.";
    } else {
        // Simulated valid credentials (replace these with your actual staff credentials)
        $validCredentials = [
            "yash patil" => [
                "number" => "1604",
                "password" => "coolidea16"
            ],
            "harshal bachhav" => [
                "number" => "1234",
                "password" => "bachhav"
            ]
        ];

        // Check if the name exists in the valid credentials
        if (array_key_exists($name, $validCredentials)) {
            // Check if the ERP number and password match
            if ($validCredentials[$name]['number'] === $number && $validCredentials[$name]['password'] === $password) {
                // Set session variables
                $_SESSION['loggedin'] = true;
                $_SESSION['name'] = $name;

                // Redirect to a protected page (e.g., faculty dashboard)
                header("Location: faculty-dashboard.php");
                exit;
            } else {
                $errorMessage = "Invalid ERP number or password. Please try again.";
            }
        } else {
            $errorMessage = "Invalid name. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Login - Error</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,600,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 
</head>
<body>
    <section class="sub-header">
        <nav>
            <a href="index.html"><img src="images/logo.png"></a>
            <div class="nav-links" id="navLinks">  
                <i class="fa fa-close" onclick="hideMenu()"></i>
                <ul>
                    <li><a href="index.html">HOME</a></li>
                    <li><a href="about.html">ABOUT</a></li>
                    <li><a href="course.html">COURSE</a></li>
                    <li><a href="infrasturcture.html">GALLERY</a></li>
                    <li><a href="contact.html">CONTACT</a></li>
                </ul>
            </div>
            <i class="fa fa-bars" onclick="showMenu()"></i>
        </nav>   
        <h1>Faculty Login</h1>
        <br>
        <section class="contact-us">
            <div class="contact-col">
                <br><br><h1 style="color: indigo;">Login Error</h1><br>
                <p style="color: red;"><?php echo $errorMessage; ?></p>
                <a href="faculty-login.html" style="color: blue;">Go back to login</a>
            </div>
        </section>            
    </section>

    <!-------footer------->>
    <section class="footer">
        <h4>About Us</h4>
        <p>Our institution is dedicated to fostering a vibrant learning environment, empowering students with knowledge,<br> skills, and values to excel in their chosen fields. Join us in a journey of discovery and growth!</p>
        <div class="icons">
            <a href="https://www.facebook.com/ACBCS2009/"><i class="fa fa-facebook"></i></a>
            <a href="https://www.instagram.com/acbcs_official/"><i class="fa fa-instagram"></i></a>
            <a href="https://in.linkedin.com/in/ashoka-acbcs-449644295"><i class="fa fa-linkedin"></i></a>
        </div>
        <p>Project by Yash V. Patil<br>Harshal Bachhav<br>Durgesh Marathe<br>& Prem Dube</p>
    </section>    

    <!----JavaScript for toggle menu---->
    <script>
        var navLinks = document.getElementById