<?php
// Start the session
session_start();

// Sample data to simulate a database
$students = [
    ['name' => 'harshal bachhav', 'number' => '1234', 'password' => 'bachhav'],
    ['name' => 'yash patil', 'number' => '1604', 'password' => 'coolidea'],
];

// Initialize variables
$name = $number = $password = "";
$error = "";

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $name = trim($_POST['name']);
    $number = trim($_POST['number']);
    $password = trim($_POST['password']);

    // Validate input
    if (empty($name) || empty($number) || empty($password)) {
        $error = "All fields are required.";
    } else {
        // Check credentials
        $found = false;
        foreach ($students as $student) {
            if ($student['name'] === $name && $student['number'] === $number && $student['password'] === $password) {
                $found = true;
                break;
            }
        }

        if ($found) {
            // Successful login
            $_SESSION['name'] = $name;
            header("Location:demo.html"); // Redirect to a welcome page
            exit();
        } else {
            $error = "Invalid credentials. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Error</title>
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,600,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="error-message" style="color: red; text-align: center;">
        <?php if (!empty($error)) echo $error; ?>
    </div>
    <a href="student.html">Go back to login</a>
</body>
</html>