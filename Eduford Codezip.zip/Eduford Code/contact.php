<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect and sanitize input data
    $name = htmlspecialchars(trim($_POST['name']));
    $number = htmlspecialchars(trim($_POST['number']));
    $email = htmlspecialchars(trim($_POST['email']));
    $address = htmlspecialchars(trim($_POST['address']));
    $message = htmlspecialchars(trim($_POST['message']));

    // Validate input data
    $errors = [];
    
    if (empty($name)) {
        $errors[] = "Name is required.";
    }
    
    if (empty($number) || !preg_match('/^[0-9]{10}$/', $number)) {
        $errors[] = "A valid 10-digit phone number is required.";
    }
    
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "A valid email address is required.";
    }
    
    if (empty($address)) {
        $errors[] = "Address is required.";
    }
    
    if (empty($message)) {
        $errors[] = "Message is required.";
    }

    // If there are errors, display them
    if (!empty($errors)) {
        foreach ($errors as $error) {
            echo "<p style='color:red;'>$error</p>";
        }
        exit; // Stop further execution
    }

    // Prepare email
    $to = "acbcs@aef.edu.in"; // Change this to your email address
    $subject = "New Contact Form Submission";
    $body = "Name: $name\n";
    $body .= "Phone Number: $number\n";
    $body .= "Email: $email\n";
    $body .= "Address: $address\n";
    $body .= "Message: $message\n";
    
    $headers = "From: $email";

    // Send email
    if (mail($to, $subject, $body, $headers)) {
        echo "<p style='color:green;'>Message sent successfully!</p>";
    } else {
        echo "<p style='color:red;'>Failed to send message. Please try again later.</p>";
    }
} else {
    echo "<p style='color:red;'>Invalid request method.</p>";
}
?>